/**
 * 
 */
/**
 * @author sksk0
 *
 */
module Java {
}